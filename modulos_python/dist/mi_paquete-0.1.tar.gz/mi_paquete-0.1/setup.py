from setuptools import setup

setup(
    name="mi_paquete",
    version="0.1",
    description="Este es un paquete de jemplo",
    author="Hector Costa",
    author_email="hola@hektorprofe.com",
    url="http://www.hektorprofe.net",
    packages=['mi_paquete'],
    scripts=[]
    
)
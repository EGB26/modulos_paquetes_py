frase = 'CoderHouse'

def calcular_factorial(numero):
    factorial = 1
    for n in range(1, (numero+1)):
        factorial += n
    return factorial